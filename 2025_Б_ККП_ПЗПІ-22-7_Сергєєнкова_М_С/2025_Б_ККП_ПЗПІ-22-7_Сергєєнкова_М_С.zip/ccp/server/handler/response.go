package handler

import (
	"github.com/gin-gonic/gin"
)

type errorResponse struct {
	Message string `json:"message"`
}

type statusResponse struct {
	Status string `json:"status"`
}

func newErrorResponse(c *gin.Context, statusCode int, message string) {
	setCORSHeaders(c)
	c.AbortWithStatusJSON(statusCode, map[string]interface{}{
		"error": message,
	})
}

func setCORSHeaders(c *gin.Context) {
	c.Header("Access-Control-Allow-Origin", "http://localhost:5173")
	c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Authorization")
	c.Header("Access-Control-Allow-Methods", "GET, HEAD, POST, PUT, DELETE, OPTIONS, PATCH")
	c.Header("Access-Control-Allow-Credentials", "true")
}
