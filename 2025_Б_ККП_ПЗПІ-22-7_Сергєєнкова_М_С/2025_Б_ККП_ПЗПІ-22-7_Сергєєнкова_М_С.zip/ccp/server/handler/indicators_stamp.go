package handler

import (
	"clinic/server/structures"
	"github.com/gin-gonic/gin"
	"strconv"
)

func (h *Handler) createIndicatorsStamp(c *gin.Context) {
	var input structures.IndicatorsStamp
	if err := c.BindJSON(&input); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	err := h.services.IndicatorsStampAction.Create(input)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{"message": "Indicators stamp created"})
}

func (h *Handler) getAllIndicatorsStamps(c *gin.Context) {
	stamps, err := h.services.IndicatorsStampAction.GetAll()
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, stamps)
}

func (h *Handler) getIndicatorsStampById(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		c.JSON(400, gin.H{"error": "invalid id"})
		return
	}

	stamp, err := h.services.IndicatorsStampAction.GetById(id)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	device, err := h.services.DeviceAction.Get(stamp.DeviceId)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	patient, err := h.services.PatientAction.GetById(device.PatientId)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	result := struct {
		Timestamp              string  `json:"timestamp"`
		Pulse                  int     `json:"pulse" binding:"required"`
		SystolicBloodPressure  int     `json:"systolic_blood_pressure" binding:"required" db:"systolic_blood_pressure"`
		DiastolicBloodPressure int     `json:"distolic_blood_pressure" binding:"required" db:"distolic_blood_pressure"`
		Temperature            float64 `json:"temperature" binding:"required"`
		PatientId              int     `json:"patient_id"`
	}{
		PatientId:              patient.Id,
		Timestamp:              stamp.Timestamp,
		Pulse:                  stamp.Pulse,
		SystolicBloodPressure:  stamp.SystolicBloodPressure,
		DiastolicBloodPressure: stamp.DiastolicBloodPressure,
		Temperature:            stamp.Temperature,
	}

	c.JSON(200, result)
}
