package repository

import (
	"clinic/server/structures"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/jmoiron/sqlx"
	"github.com/stretchr/testify/assert"
)

func setupMockDB(t *testing.T) (*sqlx.DB, sqlmock.Sqlmock, func()) {
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	sqlxDB := sqlx.NewDb(db, "sqlmock")
	return sqlxDB, mock, func() {
		db.Close()
	}
}

func TestCreatePatient(t *testing.T) {
	db, mock, teardown := setupMockDB(t)
	defer teardown()

	repo := NewPatientPostgres(db)
	patient := structures.Patient{
		User: structures.User{
			Email:        "test@example.com",
			Name:         "John",
			Surname:      "Doe",
			PasswordHash: "hash",
		},
		Birthday: time.Date(1990, time.March, 1, 0, 0, 0, 0, time.UTC),
		Sex:      true,
	}

	mock.ExpectQuery("INSERT INTO public.\"patients\"").
		WithArgs(patient.Email, patient.Name, patient.Surname, patient.PasswordHash, patient.Birthday, patient.Sex).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))

	id, err := repo.Create(patient)
	assert.NoError(t, err)
	assert.Equal(t, 1, id)
}

func TestGetPatientById(t *testing.T) {
	db, mock, teardown := setupMockDB(t)
	defer teardown()

	repo := NewPatientPostgres(db)

	expected := structures.Patient{
		User: structures.User{
			Id:           1,
			Email:        "test@example.com",
			Name:         "John",
			Surname:      "Doe",
			PasswordHash: "hash",
		},
		Birthday: time.Date(1990, time.March, 1, 0, 0, 0, 0, time.UTC),
		Sex:      true,
	}

	rows := sqlmock.NewRows([]string{"id", "email", "name", "surname", "password_hash", "birthday", "sex"}).
		AddRow(expected.Id, expected.Email, expected.Name, expected.Surname, expected.PasswordHash, expected.Birthday, expected.Sex)

	mock.ExpectQuery("SELECT \\* FROM public.\"patients\" WHERE id = \\$1").
		WithArgs(1).WillReturnRows(rows)

	patient, err := repo.GetById(1)
	assert.NoError(t, err)
	assert.Equal(t, expected, patient)
}

func TestDeletePatient(t *testing.T) {
	db, mock, teardown := setupMockDB(t)
	defer teardown()

	repo := NewPatientPostgres(db)

	mock.ExpectExec("DELETE FROM public.\"patients\" WHERE id = \\$1").
		WithArgs(1).
		WillReturnResult(sqlmock.NewResult(0, 1))

	err := repo.Delete(1)
	assert.NoError(t, err)
}
